public class Solution {
    public static int reverse(int n) {
        int tenTimes = 0;
        while (n != 0) {
            tenTimes = tenTimes * 10 + n % 10;
            n /= 10;
        }
        return tenTimes;
    }
}