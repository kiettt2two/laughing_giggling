public class Main {
    public static void main(String[] args) {
        Solution sol = new Solution();

        System.out.println(sol.reverse(9));
        System.out.println(sol.reverse(140));
        System.out.println(sol.reverse(-365));
        System.out.println(sol.reverse(123456789));
        System.out.println(sol.reverse(0));
    }
}