public class Main {
    public static void main(String[] args) {
        Solution sol = new Solution();

        System.out.printf("f(%d) = %d\n", 5, sol.fibonacci(5));
        System.out.printf("f(%d) = %d\n", 0, sol.fibonacci(0));
        System.out.printf("f(%d) = %d\n", 1, sol.fibonacci(1));
        System.out.printf("f(%d) = %d\n", 10, sol.fibonacci(10));
        System.out.printf("f(%d) = %d\n", 1, sol.fibonacci(50));
        System.out.printf("f(%d) = %d\n", 100, sol.fibonacci(100));
        System.out.printf("f(%d) = %d\n", -100, sol.fibonacci(-100));
    }
}