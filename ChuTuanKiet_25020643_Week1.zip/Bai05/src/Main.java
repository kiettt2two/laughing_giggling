public class Main {
    public static void main(String[] args) {
        Solution sol = new Solution();

        System.out.println(sol.gcd(5,5));
        System.out.println(sol.gcd(8,7));
        System.out.println(sol.gcd(100000000,48));
        System.out.println(sol.gcd(0, 10000));
        System.out.println(sol.gcd(10000,0));
        System.out.println(sol.gcd(-2,4));
        System.out.println(sol.gcd(-4,-2));
        System.out.println(sol.gcd(-4,2));
        System.out.println(sol.gcd(0,0));
    }
}