public class Main {
    public static void main(String[] args) {
        Solution sol = new Solution();

        System.out.println(sol.isPalindrome(0));
        System.out.println(sol.isPalindrome(-10));
        System.out.println(sol.isPalindrome(10));
        System.out.println(sol.isPalindrome(101));
        System.out.println(sol.isPalindrome(1001));
        System.out.println(sol.isPalindrome(1010));
        System.out.println(sol.isPalindrome(123454321));
        System.out.println(sol.isPalindrome(-12321));
    }
}