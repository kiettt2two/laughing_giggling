Bài 1.3: Phân tích Object - Hãy chỉ ra trạng thái, hành vi, định danh của đối tượng trong đoạn mã dưới đây:



a) BankAccount:

* **Trạng thái:**

&#x09;**+ accountNumber: Số tài khoản (String)**

&#x09;**+ ownerName: Tên chủ sở hữu tài khoản (String)**

&#x09;**+ balance = 0.0: Số dư tài khoản, mặc định là 0.0 (double)**



* **Hành vi:**

&#x09;**+ openAccount(accNum, owner): Mở tài khoản**

&#x09;**+ deposit(double amount): Nạp thêm tiền vào tài khoản**

&#x09;**+ withdraw(double amount): Rút tiền ra khỏi tài khoản**



* **Định danh:**

&#x09;**+ myAccount = new BankAccount(): Được khởi tạo trong hàm main**



b) SmartFan:

* **Trạng thái:**

&#x09;**+ brand: Thương hiệu quạt (String)**

&#x09;**+ isPowerOn: Trạng thái nguồn, mặc định là false (boolean)**

&#x09;**+ speedLevel: Tốc độ quạt, mặc định là 0, nhận giá trị từ 1 đến 3 (int)**



* **Hành vi:**

&#x09;**+ turnOn(): Bật quạt**

&#x09;**+ turnOff(): Tắt quạt và đặt tốc độ về 0**

&#x09;**+ setSpeed(int newSpeed): Chỉnh tốc độ quạt, chỉ hoạt động khi quạt đang bật**



* **Định danh:**

&#x09;**+ livingRoomFan = new SmartFan()**

&#x09;**+ bedroomFan = new SmartFan()**

