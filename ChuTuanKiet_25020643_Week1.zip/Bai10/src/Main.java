public class Main {
    public static void main(String[] args) {
        Solution sol = new Solution();

        System.out.println(sol.secondLargest(new int[]{1, 2, 3, 4, 5, 6, 7}));
        System.out.println(sol.secondLargest(new int[]{}));
        System.out.println(sol.secondLargest(new int[]{7}));
        System.out.println(sol.secondLargest(new int[]{10, 10, 20}));
        System.out.println(sol.secondLargest(new int[]{10, 20, 20}));
        System.out.println(sol.secondLargest(new int[]{1, 1, 1, 1}));
    }
}