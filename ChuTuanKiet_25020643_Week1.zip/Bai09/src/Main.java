public class Main {
    public static void main(String[] args) {
        Solution sol = new Solution();

        System.out.println(sol.sumOfDigits(-9));
        System.out.println(sol.sumOfDigits(-43085));
        System.out.println(sol.sumOfDigits(4321));
        System.out.println(sol.sumOfDigits(0));
        System.out.println(sol.sumOfDigits(123456789));
    }
}