public class Main {
    public static void main(String[] args) {
        Solution sol = new Solution();

        System.out.println(sol.isPrime(1));
        System.out.println(sol.isPrime(2));
        System.out.println(sol.isPrime(3));
        System.out.println(sol.isPrime(4));
        System.out.println(sol.isPrime(5));
        System.out.println(sol.isPrime(0));
        System.out.println(sol.isPrime(-1));
        System.out.println(sol.isPrime(-2));
        System.out.println(sol.isPrime(36));
        System.out.println(sol.isPrime(59));
        System.out.println(sol.isPrime(1000000000));
    }
}